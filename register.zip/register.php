<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <label for="name">Names</label>
        <input type="text" name="st_name" id=""> <br> <br>

        <label for="st_age">AGE</label>
        <input type="text" name="st_age" id=""> <br> <br>

        <label for="email">EMAIL</label>
        <input type="text" name="email" id=""> <br> <br>

        <button>submit</button>
    </form>
    <?php
    error_reporting(0);
    include 'connect.php';
$a=$_POST['st_name'];
$b=$_POST['st_age'];
$c=$_POST['email'];

$sql=mysqli_query($conn,"INSERT INTO `student`(`st_name`, `st_age`, `email`) VALUES ('$a','$b','$c')");

// header("location:select.php");
// if ($sql) {
//     echo "<script>alert('well done !!');
//     window.location.href='select.php'</script>";
// }

    
    ?>
</body>
</html>