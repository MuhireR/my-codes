<?php
include 'connect.php';
$sql=mysqli_query($conn,"SELECT * FROM student");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <button><a href="register.php">+ NEW STUDENT</a></button>
    <table border="1">
        <tr>
            <th>#</th>
            <th>StudentName</th>
            <th>AGE</th>
            <th>EMAIL</th>
            <th colspan="2">Action</th>
        </tr>
        <?php
        while ($row=mysqli_fetch_assoc($sql)) {
        ?>
        <tr>
            <td><?php echo $row['st_id'] ;  ?></td>
            <td><?php echo $row['st_name'] ;  ?></td>
            <td><?php echo $row['st_age'] ;  ?></td>
            <td><?php echo $row['email'] ;  ?></td>

            <td>
                <button><a href="update.php?demo=<?php echo $row['st_id'] ;  ?>">CHANGE</a></button>
                <button><a href="delete.php?demo=<?php echo $row['st_id'] ;  ?>">REMOVE</a></button>
            </td>

        </tr>
        <?php
        }
        ?>
    </table>
</body>
</html>
